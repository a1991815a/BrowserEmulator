#include "LogServer.h"
#include <winsock.h>
#include <conio.h>

#pragma comment(lib, "Ws2_32.lib")

DWORD WINAPI ThreadProc(LPVOID param);

LogServer::LogServer()
{
	WSADATA wsadata = {};
	int result = WSAStartup(MAKEWORD(2, 2), &wsadata);
	if(result != 0)
		exit(result);
}

LogServer::~LogServer()
{
	WSACleanup();
}

void LogServer::setPort(int port)
{
	m_iPort = port;
}

void LogServer::run()
{
	SOCKET s = socket(AF_INET, SOCK_STREAM, 0);
	SOCKADDR_IN addr = {};
	addr.sin_family = AF_INET;
	addr.sin_port = htons(m_iPort);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);

	int result = bind(s, (sockaddr*)&addr, sizeof(addr));
	const auto& ipAddr = addr.sin_addr.S_un.S_un_b;
	printf("�󶨵�ַ: %d.%d.%d.%d:%d\n", ipAddr.s_b1, ipAddr.s_b2, ipAddr.s_b3, ipAddr.s_b4, m_iPort);
	if (result != S_OK)
	{
		printf("bind error: %d\n", result);
		return;
	}
	printf("���ü���...\n");
	listen(s, 5);
	m_listenSocket = s;


	HANDLE thread = ::CreateThread(NULL, 4096, ThreadProc, this, 0, NULL);
	::WaitForSingleObject(thread, INFINITE);
	::CloseHandle(thread);
}

void LogServer::remove(SOCKET s)
{
	auto iter = m_vecSockets.begin();
	for (; iter != m_vecSockets.end(); ++iter)
	{
		if (*iter == s)
		{
			m_vecSockets.erase(iter);
			return;
		}
	}
}

SOCKET LogServer::getListenSocket() const
{
	return m_listenSocket;
}

std::vector<SOCKET>& LogServer::getClientList()
{
	return m_vecSockets;
}

DWORD WINAPI ThreadProc(LPVOID param)
{
	static const timeval timeout = {1, 2};
	printf("��ѯ�߳�����\n");
	LogServer* logServer = (LogServer*)param;

	std::vector<SOCKET>& clientList = logServer->getClientList();

	fd_set readSet = {};
	fd_set tmpSet = {};
	FD_ZERO(&readSet);
	FD_SET(logServer->getListenSocket(), &readSet);
	for (auto iter = clientList.begin(); iter != clientList.end() && tmpSet.fd_count <= FD_SETSIZE; ++iter)
		FD_SET(*iter, &readSet);

	printf("��������...\n");
	while (true)
	{
		tmpSet = readSet;
		int result = 0;
		if ((result = select(FD_SETSIZE, &tmpSet, NULL, NULL, NULL)) < 0)
		{
			printf("��ѯʧ�ܣ�%d ...\n", result);
			return result;
		};
		if (FD_ISSET(logServer->getListenSocket(), &tmpSet))
		{
			SOCKADDR_IN addr = {};
			int len = sizeof(addr);
			SOCKET s = accept(logServer->getListenSocket(), (sockaddr*)&addr, &len);
			const auto& ipAddr = addr.sin_addr.S_un.S_un_b;
			//printf("��������: %d.%d.%d.%d\n", ipAddr.s_b1, ipAddr.s_b2, ipAddr.s_b3, ipAddr.s_b4);
			clientList.push_back(s);
			FD_SET(s, &readSet);
		};

		for (size_t i = 0; i < clientList.size(); ++i)
		{
			SOCKET s = clientList.at(i);
			if(!FD_ISSET(s, &tmpSet))
				continue;
			char text[1024] = {};
			result = recv(s, text, sizeof(text), 0);
			if (result <= 0)
			{
				logServer->remove(s);
				FD_CLR(s, &readSet);
				//printf("�Ͽ�һ���ͻ���...\n");
				closesocket(s);
				continue;
			}

			printf("%s\n", text);
		}

		if (_kbhit() != 0)
		{
			if(_getch() == VK_ESCAPE)
				break;
		}
	}

	printf("��ѯ�߳̽���\n");
	return 0;
}