#ifndef __LOGSERVER_H__
#define __LOGSERVER_H__
#include <vector>
#include <windows.h>

class LogServer
{
public:
	LogServer();
	~LogServer();
	void setPort(int port);
	void run();

	void remove(SOCKET s);
	SOCKET getListenSocket() const;
	std::vector<SOCKET>& getClientList();
private:
	std::vector<SOCKET> m_vecSockets;
	int m_iPort;
	SOCKET m_listenSocket;
};
#endif
