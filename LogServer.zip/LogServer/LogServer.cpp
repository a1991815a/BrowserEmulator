#include "LogServer.h"

#pragma comment(lib, "Ws2_32.lib")

DWORD WINAPI ThreadProc(LPVOID param);

LogServer::LogServer()
{
	WSADATA wsadata = {};
	int result = WSAStartup(MAKEWORD(1, 1), &wsadata);
	if(result != 0)
		exit(result);
}

LogServer::~LogServer()
{
	WSACleanup();
}

void LogServer::setPort(int port)
{
	m_iPort = port;
}

void LogServer::run()
{
	SOCKET s = socket(AF_INET, SOCK_STREAM, 0);
	SOCKADDR_IN addr = {};
	addr.sin_family = AF_INET;
	addr.sin_port = htons(m_iPort);
	addr.sin_addr.s_addr = htonl(INADDR_ANY);

	int result = bind(s, (sockaddr*)&addr, sizeof(addr));
	if (result != S_OK)
	{
		printf("bind error: %d\n", result);
		return;
	}

	listen(s, 5);

	while (true) 
	{
		SOCKADDR_IN clientAddr = {};
		int len = sizeof(clientAddr);
		SOCKET client = accept(s, (sockaddr*)&clientAddr, &len);
		if (client == SOCKET_ERROR)
		{
			printf("accept error: 0x%X\n", ::GetLastError());
			continue;
		}
		m_vecSockets.push_back(client);
		LogClient* logClient = new LogClient();
		logClient->s = client;
		logClient->section = &m_section;
		HANDLE thread = ::CreateThread(NULL, NULL, ThreadProc, logClient, 0, NULL);
		::ResumeThread(thread);
		::CloseHandle(thread);
	};
}

DWORD WINAPI ThreadProc(LPVOID param)
{
	LogClient* logClient = (LogClient*)param;
	SOCKET s = logClient->s;
	CRITICAL_SECTION* section = logClient->section;

	char text[1024] = {};
	while(true)
	{
		int len = recv(s, text, sizeof(text), 0);
		if (len <= 0)
			continue;
		EnterCriticalSection(section);
		printf(text);
		LeaveCriticalSection(section);
	};

	return 0;
}