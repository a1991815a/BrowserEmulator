#ifndef __LOGSERVER_H__
#define __LOGSERVER_H__
#include <vector>
#include <windows.h>

typedef struct {
	SOCKET s;
	CRITICAL_SECTION* section;
} LogClient;

class LogServer
{
public:
	LogServer();
	~LogServer();
	void setPort(int port);
	void run();
private:
	std::vector<SOCKET> m_vecSockets;
	int m_iPort;
	CRITICAL_SECTION m_section;
};
#endif
