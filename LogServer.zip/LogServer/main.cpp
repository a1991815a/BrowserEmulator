#include <stdio.h>
#include "LogServer.h"

int main()
{
	LogServer logServer;
	logServer.setPort(9001);
	logServer.run();
	return 0;
}