#include "LogClient.h"

bool LogClient::isInit = false;

int LogClient::clientCount = 0;

LogClient::LogClient(const char* ip, int port /*= 9001*/)
{
	if (!LogClient::isInit)
	{
		WSADATA data = {};
		WSAStartup(MAKEWORD(1, 1), &data);
	}

	++clientCount;

	m_socket = socket();
}

LogClient::~LogClient()
{
	if (--clientCount == 0 && isInit)
		WSACleanup();
}

void LogClient::log(const char* text, ...)
{

}

void LogClient::log(const wchar_t* text, ...)
{

}
