#include <stdio.h>
#include "LogServer.h"

int main()
{
	LogServer logServer;
	logServer.setPort(9001);
	logServer.run();

// 	LogClient logClient("127.0.0.1");
// 	logClient.log("file:%s  line:%d  msg:����һ��������Ϣ", __FILE__, __LINE__);
	return 0;
}